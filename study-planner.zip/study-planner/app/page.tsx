'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import { 
  AcademicCapIcon, 
  MicrophoneIcon, 
  CalendarIcon, 
  ChartBarIcon,
  CheckCircleIcon,
  BookOpenIcon
} from '@heroicons/react/24/outline'
import VoiceGoalInput from './components/VoiceGoalInput'
import GoalSelector from './components/GoalSelector'
import StudyPlanGenerator from './components/StudyPlanGenerator'
import TimelineSetup from './components/TimelineSetup'

export default function Home() {
  const [currentStep, setCurrentStep] = useState(0)
  const [goals, setGoals] = useState<any[]>([])
  const [timeline, setTimeline] = useState<any>(null)
  const [studyPlan, setStudyPlan] = useState<any>(null)

  const steps = [
    { id: 0, title: 'Set Your Goals', icon: AcademicCapIcon },
    { id: 1, title: 'Define Timeline', icon: CalendarIcon },
    { id: 2, title: 'Generate Plan', icon: ChartBarIcon },
    { id: 3, title: 'Track Progress', icon: CheckCircleIcon }
  ]

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  }

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        duration: 0.5
      }
    }
  }

  return (
    <div className="min-h-screen">
      {/* Header */}
      <motion.header 
        initial={{ y: -50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.6 }}
        className="bg-white shadow-sm border-b border-gray-200"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <BookOpenIcon className="h-8 w-8 text-primary-600" />
              <h1 className="text-2xl font-bold text-gray-900">University Study Planner</h1>
            </div>
            <div className="hidden md:flex items-center space-x-8">
              {steps.map((step, index) => (
                <div key={step.id} className="flex items-center space-x-2">
                  <div className={`flex items-center justify-center w-8 h-8 rounded-full ${
                    index <= currentStep ? 'bg-primary-600 text-white' : 'bg-gray-200 text-gray-500'
                  }`}>
                    {index < currentStep ? (
                      <CheckCircleIcon className="h-5 w-5" />
                    ) : (
                      <step.icon className="h-5 w-5" />
                    )}
                  </div>
                  <span className={`text-sm font-medium ${
                    index <= currentStep ? 'text-primary-600' : 'text-gray-500'
                  }`}>
                    {step.title}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </motion.header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="space-y-8"
        >
          {/* Welcome Section */}
          {currentStep === 0 && (
            <motion.div variants={itemVariants} className="text-center mb-12">
              <h2 className="text-4xl font-bold text-gray-900 mb-4">
                Achieve Your Academic Goals
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Create a personalized study plan tailored to your courses, timeline, and learning style. 
                Set goals through voice commands or choose from our curated list.
              </p>
            </motion.div>
          )}

          {/* Step Content */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            {/* Main Content Area */}
            <div className="lg:col-span-8">
              {currentStep === 0 && (
                <motion.div variants={itemVariants} className="space-y-6">
                  <div className="card">
                    <h3 className="text-2xl font-bold text-gray-900 mb-6">How would you like to set your goals?</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <VoiceGoalInput onGoalAdded={(goal) => setGoals([...goals, goal])} />
                      <GoalSelector onGoalSelected={(goal) => setGoals([...goals, goal])} />
                    </div>
                  </div>
                  
                  {goals.length > 0 && (
                    <div className="card">
                      <h4 className="text-lg font-semibold text-gray-900 mb-4">Your Goals</h4>
                      <div className="space-y-3">
                        {goals.map((goal, index) => (
                          <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                            <div>
                              <h5 className="font-medium text-gray-900">{goal.title}</h5>
                              <p className="text-sm text-gray-600">{goal.description}</p>
                              {goal.course && <span className="text-xs bg-primary-100 text-primary-800 px-2 py-1 rounded-full mt-1 inline-block">{goal.course}</span>}
                            </div>
                            <button 
                              onClick={() => setGoals(goals.filter((_, i) => i !== index))}
                              className="text-red-500 hover:text-red-700"
                            >
                              Remove
                            </button>
                          </div>
                        ))}
                      </div>
                      <button 
                        onClick={() => setCurrentStep(1)}
                        className="btn-primary mt-4 w-full"
                      >
                        Continue to Timeline Setup
                      </button>
                    </div>
                  )}
                </motion.div>
              )}

              {currentStep === 1 && (
                <motion.div variants={itemVariants}>
                  <TimelineSetup 
                    goals={goals}
                    onTimelineSet={(timelineData) => {
                      setTimeline(timelineData)
                      setCurrentStep(2)
                    }}
                    onBack={() => setCurrentStep(0)}
                  />
                </motion.div>
              )}

              {currentStep === 2 && (
                <motion.div variants={itemVariants}>
                  <StudyPlanGenerator
                    goals={goals}
                    timeline={timeline}
                    onPlanGenerated={(plan) => {
                      setStudyPlan(plan)
                      setCurrentStep(3)
                    }}
                    onBack={() => setCurrentStep(1)}
                  />
                </motion.div>
              )}

              {currentStep === 3 && studyPlan && (
                <motion.div variants={itemVariants} className="card">
                  <h3 className="text-2xl font-bold text-gray-900 mb-6">Your Custom Study Plan</h3>
                  <div className="space-y-6">
                    {studyPlan.weeks.map((week: any, index: number) => (
                      <div key={index} className="border-l-4 border-primary-500 pl-4">
                        <h4 className="font-semibold text-lg text-gray-900">Week {week.number}</h4>
                        <p className="text-gray-600 mb-3">{week.focus}</p>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          {week.tasks.map((task: any, taskIndex: number) => (
                            <div key={taskIndex} className="bg-gray-50 p-3 rounded-lg">
                              <h5 className="font-medium text-gray-900">{task.title}</h5>
                              <p className="text-sm text-gray-600">{task.description}</p>
                              <span className="text-xs bg-secondary-100 text-secondary-800 px-2 py-1 rounded-full mt-2 inline-block">
                                {task.estimatedTime}
                              </span>
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                  <button 
                    onClick={() => setCurrentStep(0)}
                    className="btn-secondary mt-6"
                  >
                    Create New Plan
                  </button>
                </motion.div>
              )}
            </div>

            {/* Sidebar */}
            <div className="lg:col-span-4">
              <motion.div variants={itemVariants} className="card sticky top-8">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Study Tips</h3>
                <div className="space-y-4">
                  <div className="flex items-start space-x-3">
                    <div className="flex-shrink-0 w-2 h-2 bg-primary-500 rounded-full mt-2"></div>
                    <p className="text-sm text-gray-600">Break large goals into smaller, manageable tasks</p>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="flex-shrink-0 w-2 h-2 bg-primary-500 rounded-full mt-2"></div>
                    <p className="text-sm text-gray-600">Use the Pomodoro Technique for focused study sessions</p>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="flex-shrink-0 w-2 h-2 bg-primary-500 rounded-full mt-2"></div>
                    <p className="text-sm text-gray-600">Schedule regular breaks to maintain productivity</p>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="flex-shrink-0 w-2 h-2 bg-primary-500 rounded-full mt-2"></div>
                    <p className="text-sm text-gray-600">Review and adjust your plan weekly</p>
                  </div>
                </div>
              </motion.div>
            </div>
          </div>
        </motion.div>
      </main>
    </div>
  )
}
