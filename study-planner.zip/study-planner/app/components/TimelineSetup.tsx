'use client'

import { useState } from 'react'
import { CalendarIcon, ClockIcon, AcademicCapIcon } from '@heroicons/react/24/outline'
import { motion } from 'framer-motion'

interface TimelineSetupProps {
  goals: any[]
  onTimelineSet: (timeline: any) => void
  onBack: () => void
}

const semesterTemplates = [
  {
    id: 'fall-2024',
    name: 'Fall 2024',
    startDate: '2024-08-26',
    endDate: '2024-12-15',
    midtermWeek: '2024-10-14',
    finalsWeek: '2024-12-09',
    breaks: [
      { name: 'Labor Day', date: '2024-09-02' },
      { name: 'Thanksgiving Break', start: '2024-11-25', end: '2024-11-29' }
    ]
  },
  {
    id: 'spring-2025',
    name: 'Spring 2025',
    startDate: '2025-01-13',
    endDate: '2025-05-10',
    midtermWeek: '2025-03-10',
    finalsWeek: '2025-05-05',
    breaks: [
      { name: 'MLK Day', date: '2025-01-20' },
      { name: 'Spring Break', start: '2025-03-17', end: '2025-03-21' }
    ]
  },
  {
    id: 'summer-2025',
    name: 'Summer 2025',
    startDate: '2025-06-02',
    endDate: '2025-08-15',
    midtermWeek: '2025-07-07',
    finalsWeek: '2025-08-11',
    breaks: [
      { name: 'Independence Day', date: '2025-07-04' }
    ]
  }
]

const studyIntensityLevels = [
  {
    id: 'light',
    name: 'Light',
    description: '1-2 hours daily, weekends flexible',
    hoursPerWeek: 10,
    color: 'bg-green-100 text-green-800'
  },
  {
    id: 'moderate',
    name: 'Moderate',
    description: '2-3 hours daily, consistent schedule',
    hoursPerWeek: 18,
    color: 'bg-yellow-100 text-yellow-800'
  },
  {
    id: 'intensive',
    name: 'Intensive',
    description: '3-4 hours daily, focused approach',
    hoursPerWeek: 25,
    color: 'bg-red-100 text-red-800'
  }
]

export default function TimelineSetup({ goals, onTimelineSet, onBack }: TimelineSetupProps) {
  const [selectedTemplate, setSelectedTemplate] = useState<string>('')
  const [customDates, setCustomDates] = useState({
    startDate: '',
    endDate: '',
    midtermDate: '',
    finalDate: ''
  })
  const [studyIntensity, setStudyIntensity] = useState<string>('')
  const [studyPreferences, setStudyPreferences] = useState({
    preferredTimes: [] as string[],
    studyDuration: 90,
    breakFrequency: 25,
    weekendStudy: true
  })
  const [customEvents, setCustomEvents] = useState<any[]>([])
  const [newEvent, setNewEvent] = useState({ name: '', date: '', type: 'exam' })

  const timeSlots = [
    'Early Morning (6-9 AM)',
    'Morning (9-12 PM)',
    'Afternoon (12-3 PM)',
    'Late Afternoon (3-6 PM)',
    'Evening (6-9 PM)',
    'Night (9-12 AM)'
  ]

  const handleTimePreferenceToggle = (time: string) => {
    if (studyPreferences.preferredTimes.includes(time)) {
      setStudyPreferences({
        ...studyPreferences,
        preferredTimes: studyPreferences.preferredTimes.filter(t => t !== time)
      })
    } else {
      setStudyPreferences({
        ...studyPreferences,
        preferredTimes: [...studyPreferences.preferredTimes, time]
      })
    }
  }

  const addCustomEvent = () => {
    if (newEvent.name && newEvent.date) {
      setCustomEvents([...customEvents, { ...newEvent, id: Date.now() }])
      setNewEvent({ name: '', date: '', type: 'exam' })
    }
  }

  const removeCustomEvent = (id: number) => {
    setCustomEvents(customEvents.filter(event => event.id !== id))
  }

  const handleSubmit = () => {
    const template = semesterTemplates.find(t => t.id === selectedTemplate)
    const intensity = studyIntensityLevels.find(i => i.id === studyIntensity)
    
    const timeline = {
      template: template || {
        name: 'Custom Timeline',
        startDate: customDates.startDate,
        endDate: customDates.endDate,
        midtermWeek: customDates.midtermDate,
        finalsWeek: customDates.finalDate
      },
      intensity: intensity,
      preferences: studyPreferences,
      customEvents: customEvents,
      goals: goals
    }
    
    onTimelineSet(timeline)
  }

  const isValid = (selectedTemplate || (customDates.startDate && customDates.endDate)) && studyIntensity

  return (
    <div className="card max-w-4xl mx-auto">
      <div className="mb-8">
        <h3 className="text-2xl font-bold text-gray-900 mb-2">Define Your Timeline</h3>
        <p className="text-gray-600">
          Set up your semester schedule and study preferences to create a personalized plan
        </p>
      </div>

      <div className="space-y-8">
        {/* Semester Template Selection */}
        <div>
          <h4 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
            <CalendarIcon className="h-5 w-5 mr-2" />
            Choose Your Semester
          </h4>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
            {semesterTemplates.map(template => (
              <motion.div
                key={template.id}
                whileHover={{ scale: 1.02 }}
                onClick={() => setSelectedTemplate(template.id)}
                className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
                  selectedTemplate === template.id
                    ? 'border-primary-500 bg-primary-50'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <h5 className="font-medium text-gray-900 mb-2">{template.name}</h5>
                <div className="text-sm text-gray-600 space-y-1">
                  <p>Start: {new Date(template.startDate).toLocaleDateString()}</p>
                  <p>End: {new Date(template.endDate).toLocaleDateString()}</p>
                  <p>Midterms: {new Date(template.midtermWeek).toLocaleDateString()}</p>
                </div>
              </motion.div>
            ))}
          </div>
          
          <div className="bg-gray-50 p-4 rounded-lg">
            <h5 className="font-medium text-gray-900 mb-3">Or set custom dates:</h5>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Start Date</label>
                <input
                  type="date"
                  value={customDates.startDate}
                  onChange={(e) => setCustomDates({ ...customDates, startDate: e.target.value })}
                  className="input-field"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">End Date</label>
                <input
                  type="date"
                  value={customDates.endDate}
                  onChange={(e) => setCustomDates({ ...customDates, endDate: e.target.value })}
                  className="input-field"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Midterm Week</label>
                <input
                  type="date"
                  value={customDates.midtermDate}
                  onChange={(e) => setCustomDates({ ...customDates, midtermDate: e.target.value })}
                  className="input-field"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Finals Week</label>
                <input
                  type="date"
                  value={customDates.finalDate}
                  onChange={(e) => setCustomDates({ ...customDates, finalDate: e.target.value })}
                  className="input-field"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Study Intensity */}
        <div>
          <h4 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
            <ClockIcon className="h-5 w-5 mr-2" />
            Study Intensity
          </h4>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {studyIntensityLevels.map(level => (
              <motion.div
                key={level.id}
                whileHover={{ scale: 1.02 }}
                onClick={() => setStudyIntensity(level.id)}
                className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
                  studyIntensity === level.id
                    ? 'border-primary-500 bg-primary-50'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <h5 className="font-medium text-gray-900">{level.name}</h5>
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${level.color}`}>
                    {level.hoursPerWeek}h/week
                  </span>
                </div>
                <p className="text-sm text-gray-600">{level.description}</p>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Study Preferences */}
        <div>
          <h4 className="text-lg font-semibold text-gray-900 mb-4">Study Preferences</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h5 className="font-medium text-gray-900 mb-3">Preferred Study Times</h5>
              <div className="space-y-2">
                {timeSlots.map(slot => (
                  <label key={slot} className="flex items-center">
                    <input
                      type="checkbox"
                      checked={studyPreferences.preferredTimes.includes(slot)}
                      onChange={() => handleTimePreferenceToggle(slot)}
                      className="rounded border-gray-300 text-primary-600 focus:ring-primary-500"
                    />
                    <span className="ml-2 text-sm text-gray-700">{slot}</span>
                  </label>
                ))}
              </div>
            </div>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Study Session Duration (minutes)
                </label>
                <input
                  type="range"
                  min="30"
                  max="180"
                  step="15"
                  value={studyPreferences.studyDuration}
                  onChange={(e) => setStudyPreferences({
                    ...studyPreferences,
                    studyDuration: parseInt(e.target.value)
                  })}
                  className="w-full"
                />
                <div className="text-sm text-gray-600 mt-1">
                  {studyPreferences.studyDuration} minutes
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Break Frequency (minutes)
                </label>
                <input
                  type="range"
                  min="15"
                  max="60"
                  step="5"
                  value={studyPreferences.breakFrequency}
                  onChange={(e) => setStudyPreferences({
                    ...studyPreferences,
                    breakFrequency: parseInt(e.target.value)
                  })}
                  className="w-full"
                />
                <div className="text-sm text-gray-600 mt-1">
                  Every {studyPreferences.breakFrequency} minutes
                </div>
              </div>
              
              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={studyPreferences.weekendStudy}
                  onChange={(e) => setStudyPreferences({
                    ...studyPreferences,
                    weekendStudy: e.target.checked
                  })}
                  className="rounded border-gray-300 text-primary-600 focus:ring-primary-500"
                />
                <span className="ml-2 text-sm text-gray-700">Include weekend study sessions</span>
              </label>
            </div>
          </div>
        </div>

        {/* Custom Events */}
        <div>
          <h4 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
            <AcademicCapIcon className="h-5 w-5 mr-2" />
            Important Dates
          </h4>
          <div className="bg-gray-50 p-4 rounded-lg">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
              <input
                type="text"
                placeholder="Event name"
                value={newEvent.name}
                onChange={(e) => setNewEvent({ ...newEvent, name: e.target.value })}
                className="input-field"
              />
              <input
                type="date"
                value={newEvent.date}
                onChange={(e) => setNewEvent({ ...newEvent, date: e.target.value })}
                className="input-field"
              />
              <select
                value={newEvent.type}
                onChange={(e) => setNewEvent({ ...newEvent, type: e.target.value })}
                className="input-field"
              >
                <option value="exam">Exam</option>
                <option value="assignment">Assignment Due</option>
                <option value="presentation">Presentation</option>
                <option value="project">Project Due</option>
              </select>
              <button
                onClick={addCustomEvent}
                className="btn-primary"
              >
                Add Event
              </button>
            </div>
            
            {customEvents.length > 0 && (
              <div className="space-y-2">
                <h6 className="font-medium text-gray-900">Your Important Dates:</h6>
                {customEvents.map(event => (
                  <div key={event.id} className="flex items-center justify-between p-2 bg-white rounded border">
                    <div>
                      <span className="font-medium">{event.name}</span>
                      <span className="text-sm text-gray-600 ml-2">
                        {new Date(event.date).toLocaleDateString()} - {event.type}
                      </span>
                    </div>
                    <button
                      onClick={() => removeCustomEvent(event.id)}
                      className="text-red-500 hover:text-red-700"
                    >
                      Remove
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Actions */}
      <div className="flex justify-between mt-8 pt-6 border-t border-gray-200">
        <button onClick={onBack} className="btn-secondary">
          Back to Goals
        </button>
        <button 
          onClick={handleSubmit}
          disabled={!isValid}
          className={`btn-primary ${!isValid ? 'opacity-50 cursor-not-allowed' : ''}`}
        >
          Generate Study Plan
        </button>
      </div>
    </div>
  )
}
