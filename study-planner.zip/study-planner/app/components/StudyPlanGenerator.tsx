'use client'

import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { 
  BookOpenIcon, 
  ClockIcon, 
  CalendarDaysIcon,
  AcademicCapIcon,
  CheckCircleIcon,
  ExclamationTriangleIcon
} from '@heroicons/react/24/outline'

interface StudyPlanGeneratorProps {
  goals: any[]
  timeline: any
  onPlanGenerated: (plan: any) => void
  onBack: () => void
}

interface StudyTask {
  id: string
  title: string
  description: string
  type: 'reading' | 'practice' | 'review' | 'exam' | 'assignment' | 'project'
  estimatedTime: string
  priority: 'high' | 'medium' | 'low'
  course: string
  dueDate?: string
  completed: boolean
}

interface StudyWeek {
  number: number
  startDate: string
  endDate: string
  focus: string
  tasks: StudyTask[]
  totalHours: number
  examPrep?: boolean
}

export default function StudyPlanGenerator({ goals, timeline, onPlanGenerated, onBack }: StudyPlanGeneratorProps) {
  const [isGenerating, setIsGenerating] = useState(false)
  const [generationStep, setGenerationStep] = useState(0)
  const [plan, setPlan] = useState<any>(null)
  const [courses, setCourses] = useState<string[]>([])
  const [selectedCourses, setSelectedCourses] = useState<string[]>([])
  const [studyMethods, setStudyMethods] = useState<string[]>([])
  const [customization, setCustomization] = useState({
    includeGroupStudy: false,
    includePracticeExams: true,
    focusOnWeakAreas: true,
    balanceWorkload: true
  })

  const generationSteps = [
    'Analyzing your goals and timeline...',
    'Identifying course requirements...',
    'Creating personalized study schedule...',
    'Optimizing for your preferences...',
    'Generating practice exam schedule...',
    'Finalizing your custom plan...'
  ]

  const availableStudyMethods = [
    'Active Reading', 'Flashcards', 'Practice Problems', 'Group Study',
    'Video Lectures', 'Mind Maps', 'Summarization', 'Teaching Others',
    'Practice Exams', 'Laboratory Work', 'Research', 'Presentations'
  ]

  useEffect(() => {
    // Extract unique courses from goals
    const uniqueCourses = [...new Set(goals.map(goal => goal.course).filter(Boolean))]
    setCourses(uniqueCourses)
    setSelectedCourses(uniqueCourses)
  }, [goals])

  const generateStudyPlan = async () => {
    setIsGenerating(true)
    setGenerationStep(0)

    // Simulate AI plan generation with realistic delays
    for (let i = 0; i < generationSteps.length; i++) {
      setGenerationStep(i)
      await new Promise(resolve => setTimeout(resolve, 1000 + Math.random() * 1000))
    }

    // Generate the actual study plan
    const generatedPlan = createCustomStudyPlan()
    setPlan(generatedPlan)
    setIsGenerating(false)
  }

  const createCustomStudyPlan = () => {
    const startDate = new Date(timeline.template.startDate)
    const endDate = new Date(timeline.template.endDate)
    const totalWeeks = Math.ceil((endDate.getTime() - startDate.getTime()) / (7 * 24 * 60 * 60 * 1000))
    const hoursPerWeek = timeline.intensity.hoursPerWeek

    const weeks: StudyWeek[] = []
    
    for (let weekNum = 1; weekNum <= totalWeeks; weekNum++) {
      const weekStart = new Date(startDate.getTime() + (weekNum - 1) * 7 * 24 * 60 * 60 * 1000)
      const weekEnd = new Date(weekStart.getTime() + 6 * 24 * 60 * 60 * 1000)
      
      // Determine week focus based on timeline and goals
      let focus = `Week ${weekNum} - Foundation Building`
      let examPrep = false
      
      if (weekNum <= 4) {
        focus = 'Foundation and Concept Building'
      } else if (weekNum <= 8) {
        focus = 'Skill Development and Practice'
      } else if (weekNum <= 12) {
        focus = 'Advanced Topics and Application'
      } else {
        focus = 'Review and Exam Preparation'
        examPrep = true
      }

      // Check if this week has any important dates
      const midtermWeek = new Date(timeline.template.midtermWeek)
      const finalsWeek = new Date(timeline.template.finalsWeek)
      
      if (Math.abs(weekStart.getTime() - midtermWeek.getTime()) < 7 * 24 * 60 * 60 * 1000) {
        focus = 'Midterm Preparation'
        examPrep = true
      } else if (Math.abs(weekStart.getTime() - finalsWeek.getTime()) < 7 * 24 * 60 * 60 * 1000) {
        focus = 'Final Exam Preparation'
        examPrep = true
      }

      // Generate tasks for this week
      const tasks = generateWeeklyTasks(weekNum, selectedCourses, goals, hoursPerWeek, examPrep)

      weeks.push({
        number: weekNum,
        startDate: weekStart.toISOString().split('T')[0],
        endDate: weekEnd.toISOString().split('T')[0],
        focus,
        tasks,
        totalHours: tasks.reduce((sum, task) => sum + parseFloat(task.estimatedTime), 0),
        examPrep
      })
    }

    return {
      id: `plan-${Date.now()}`,
      title: 'Your Personalized Study Plan',
      description: `Custom study plan for ${goals.length} goals across ${selectedCourses.length} courses`,
      timeline: timeline,
      goals: goals,
      courses: selectedCourses,
      weeks: weeks,
      totalHours: weeks.reduce((sum, week) => sum + week.totalHours, 0),
      studyMethods: studyMethods,
      customization: customization,
      createdAt: new Date().toISOString()
    }
  }

  const generateWeeklyTasks = (weekNum: number, courses: string[], goals: any[], hoursPerWeek: number, examPrep: boolean): StudyTask[] => {
    const tasks: StudyTask[] = []
    const hoursPerCourse = Math.floor(hoursPerWeek / courses.length)

    courses.forEach((course, index) => {
      const courseGoals = goals.filter(goal => goal.course === course)
      
      if (examPrep) {
        // Exam preparation tasks
        tasks.push({
          id: `${weekNum}-${course}-review`,
          title: `${course} Comprehensive Review`,
          description: 'Review all key concepts, formulas, and important topics',
          type: 'review',
          estimatedTime: `${Math.floor(hoursPerCourse * 0.4)}`,
          priority: 'high',
          course,
          completed: false
        })

        tasks.push({
          id: `${weekNum}-${course}-practice`,
          title: `${course} Practice Exam`,
          description: 'Complete practice exams and review incorrect answers',
          type: 'exam',
          estimatedTime: `${Math.floor(hoursPerCourse * 0.6)}`,
          priority: 'high',
          course,
          completed: false
        })
      } else {
        // Regular study tasks
        const taskTypes = ['reading', 'practice', 'review'] as const
        const currentType = taskTypes[weekNum % taskTypes.length]

        if (currentType === 'reading') {
          tasks.push({
            id: `${weekNum}-${course}-reading`,
            title: `${course} Chapter Reading`,
            description: `Read assigned chapters and take detailed notes`,
            type: 'reading',
            estimatedTime: `${Math.floor(hoursPerCourse * 0.6)}`,
            priority: courseGoals.some(g => g.priority === 'high') ? 'high' : 'medium',
            course,
            completed: false
          })

          tasks.push({
            id: `${weekNum}-${course}-notes`,
            title: `${course} Note Organization`,
            description: 'Organize and review lecture notes, create study guides',
            type: 'review',
            estimatedTime: `${Math.floor(hoursPerCourse * 0.4)}`,
            priority: 'medium',
            course,
            completed: false
          })
        } else if (currentType === 'practice') {
          tasks.push({
            id: `${weekNum}-${course}-problems`,
            title: `${course} Practice Problems`,
            description: 'Complete problem sets and practice exercises',
            type: 'practice',
            estimatedTime: `${Math.floor(hoursPerCourse * 0.7)}`,
            priority: 'high',
            course,
            completed: false
          })

          tasks.push({
            id: `${weekNum}-${course}-quiz`,
            title: `${course} Self-Assessment`,
            description: 'Take online quizzes and review weak areas',
            type: 'review',
            estimatedTime: `${Math.floor(hoursPerCourse * 0.3)}`,
            priority: 'medium',
            course,
            completed: false
          })
        } else {
          tasks.push({
            id: `${weekNum}-${course}-review`,
            title: `${course} Weekly Review`,
            description: 'Review previous week\'s material and identify gaps',
            type: 'review',
            estimatedTime: `${hoursPerCourse}`,
            priority: 'medium',
            course,
            completed: false
          })
        }
      }
    })

    return tasks
  }

  const handleMethodToggle = (method: string) => {
    if (studyMethods.includes(method)) {
      setStudyMethods(studyMethods.filter(m => m !== method))
    } else {
      setStudyMethods([...studyMethods, method])
    }
  }

  const handleCourseToggle = (course: string) => {
    if (selectedCourses.includes(course)) {
      setSelectedCourses(selectedCourses.filter(c => c !== course))
    } else {
      setSelectedCourses([...selectedCourses, course])
    }
  }

  if (plan) {
    return (
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="card max-w-6xl mx-auto"
      >
        <div className="mb-8">
          <h3 className="text-2xl font-bold text-gray-900 mb-2">Your Custom Study Plan</h3>
          <div className="flex items-center space-x-6 text-sm text-gray-600">
            <span className="flex items-center">
              <CalendarDaysIcon className="h-4 w-4 mr-1" />
              {plan.weeks.length} weeks
            </span>
            <span className="flex items-center">
              <ClockIcon className="h-4 w-4 mr-1" />
              {plan.totalHours} total hours
            </span>
            <span className="flex items-center">
              <BookOpenIcon className="h-4 w-4 mr-1" />
              {plan.courses.length} courses
            </span>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Plan Overview */}
          <div className="lg:col-span-3 space-y-6">
            {plan.weeks.slice(0, 8).map((week: StudyWeek) => (
              <div key={week.number} className={`border-l-4 pl-6 ${
                week.examPrep ? 'border-red-500' : 'border-primary-500'
              }`}>
                <div className="flex items-center justify-between mb-3">
                  <h4 className="font-semibold text-lg text-gray-900">
                    Week {week.number}
                  </h4>
                  <div className="flex items-center space-x-2">
                    {week.examPrep && (
                      <span className="bg-red-100 text-red-800 text-xs px-2 py-1 rounded-full">
                        Exam Prep
                      </span>
                    )}
                    <span className="text-sm text-gray-500">
                      {week.totalHours}h total
                    </span>
                  </div>
                </div>
                <p className="text-gray-600 mb-4">{week.focus}</p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {week.tasks.map((task: StudyTask) => (
                    <div key={task.id} className="bg-gray-50 p-4 rounded-lg">
                      <div className="flex items-start justify-between mb-2">
                        <h5 className="font-medium text-gray-900 text-sm">{task.title}</h5>
                        <span className={`text-xs px-2 py-1 rounded-full ${
                          task.priority === 'high' ? 'bg-red-100 text-red-800' :
                          task.priority === 'medium' ? 'bg-yellow-100 text-yellow-800' :
                          'bg-green-100 text-green-800'
                        }`}>
                          {task.priority}
                        </span>
                      </div>
                      <p className="text-xs text-gray-600 mb-2">{task.description}</p>
                      <div className="flex items-center justify-between">
                        <span className="text-xs bg-primary-100 text-primary-800 px-2 py-1 rounded">
                          {task.course}
                        </span>
                        <span className="text-xs text-gray-500">{task.estimatedTime}h</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
            
            {plan.weeks.length > 8 && (
              <div className="text-center p-4 bg-gray-50 rounded-lg">
                <p className="text-gray-600">
                  + {plan.weeks.length - 8} more weeks in your complete plan
                </p>
              </div>
            )}
          </div>

          {/* Plan Summary */}
          <div className="space-y-6">
            <div className="bg-gradient-to-br from-primary-50 to-blue-50 p-4 rounded-lg">
              <h5 className="font-semibold text-gray-900 mb-3">Plan Summary</h5>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span>Duration:</span>
                  <span className="font-medium">{plan.weeks.length} weeks</span>
                </div>
                <div className="flex justify-between">
                  <span>Total Hours:</span>
                  <span className="font-medium">{plan.totalHours}h</span>
                </div>
                <div className="flex justify-between">
                  <span>Weekly Average:</span>
                  <span className="font-medium">{Math.round(plan.totalHours / plan.weeks.length)}h</span>
                </div>
                <div className="flex justify-between">
                  <span>Exam Prep Weeks:</span>
                  <span className="font-medium">{plan.weeks.filter((w: StudyWeek) => w.examPrep).length}</span>
                </div>
              </div>
            </div>

            <div className="bg-white p-4 rounded-lg border border-gray-200">
              <h5 className="font-semibold text-gray-900 mb-3">Your Goals</h5>
              <div className="space-y-2">
                {goals.slice(0, 3).map((goal, index) => (
                  <div key={index} className="text-sm">
                    <p className="font-medium text-gray-900">{goal.title}</p>
                    <p className="text-gray-600 text-xs">{goal.course}</p>
                  </div>
                ))}
                {goals.length > 3 && (
                  <p className="text-xs text-gray-500">+{goals.length - 3} more goals</p>
                )}
              </div>
            </div>

            <div className="bg-white p-4 rounded-lg border border-gray-200">
              <h5 className="font-semibold text-gray-900 mb-3">Study Methods</h5>
              <div className="flex flex-wrap gap-1">
                {studyMethods.slice(0, 4).map(method => (
                  <span key={method} className="text-xs bg-secondary-100 text-secondary-800 px-2 py-1 rounded">
                    {method}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>

        <div className="flex justify-between mt-8 pt-6 border-t border-gray-200">
          <button onClick={onBack} className="btn-secondary">
            Customize Plan
          </button>
          <button 
            onClick={() => onPlanGenerated(plan)}
            className="btn-primary"
          >
            Start This Plan
          </button>
        </div>
      </motion.div>
    )
  }

  if (isGenerating) {
    return (
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="card max-w-2xl mx-auto text-center"
      >
        <div className="mb-8">
          <div className="w-16 h-16 bg-primary-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <AcademicCapIcon className="h-8 w-8 text-primary-600" />
          </div>
          <h3 className="text-2xl font-bold text-gray-900 mb-2">Creating Your Custom Study Plan</h3>
          <p className="text-gray-600">
            Please wait while we analyze your goals and generate a personalized study schedule
          </p>
        </div>

        <div className="space-y-4">
          {generationSteps.map((step, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -20 }}
              animate={{ 
                opacity: index <= generationStep ? 1 : 0.3,
                x: 0
              }}
              className="flex items-center justify-between p-3 rounded-lg bg-gray-50"
            >
              <span className={`text-sm ${index <= generationStep ? 'text-gray-900' : 'text-gray-500'}`}>
                {step}
              </span>
              {index < generationStep ? (
                <CheckCircleIcon className="h-5 w-5 text-green-600" />
              ) : index === generationStep ? (
                <div className="w-5 h-5 border-2 border-primary-600 border-t-transparent rounded-full animate-spin" />
              ) : (
                <div className="w-5 h-5 border-2 border-gray-300 rounded-full" />
              )}
            </motion.div>
          ))}
        </div>

        <div className="mt-8 p-4 bg-blue-50 rounded-lg">
          <p className="text-sm text-blue-800">
            💡 Tip: Your plan will include practice exams, study schedules, and progress tracking tailored to your timeline and preferences.
          </p>
        </div>
      </motion.div>
    )
  }

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="card max-w-4xl mx-auto"
    >
      <div className="mb-8">
        <h3 className="text-2xl font-bold text-gray-900 mb-2">Customize Your Study Plan</h3>
        <p className="text-gray-600">
          Fine-tune your plan by selecting courses, study methods, and preferences
        </p>
      </div>

      <div className="space-y-8">
        {/* Course Selection */}
        <div>
          <h4 className="text-lg font-semibold text-gray-900 mb-4">Select Courses to Include</h4>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            {courses.map(course => (
              <label key={course} className="flex items-center p-3 border rounded-lg hover:bg-gray-50">
                <input
                  type="checkbox"
                  checked={selectedCourses.includes(course)}
                  onChange={() => handleCourseToggle(course)}
                  className="rounded border-gray-300 text-primary-600 focus:ring-primary-500"
                />
                <span className="ml-2 text-sm font-medium text-gray-900">{course}</span>
              </label>
            ))}
          </div>
        </div>

        {/* Study Methods */}
        <div>
          <h4 className="text-lg font-semibold text-gray-900 mb-4">Preferred Study Methods</h4>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {availableStudyMethods.map(method => (
              <label key={method} className="flex items-center p-3 border rounded-lg hover:bg-gray-50">
                <input
                  type="checkbox"
                  checked={studyMethods.includes(method)}
                  onChange={() => handleMethodToggle(method)}
                  className="rounded border-gray-300 text-primary-600 focus:ring-primary-500"
                />
                <span className="ml-2 text-sm text-gray-900">{method}</span>
              </label>
            ))}
          </div>
        </div>

        {/* Customization Options */}
        <div>
          <h4 className="text-lg font-semibold text-gray-900 mb-4">Plan Customization</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {Object.entries(customization).map(([key, value]) => (
              <label key={key} className="flex items-center p-3 border rounded-lg hover:bg-gray-50">
                <input
                  type="checkbox"
                  checked={value}
                  onChange={(e) => setCustomization({
                    ...customization,
                    [key]: e.target.checked
                  })}
                  className="rounded border-gray-300 text-primary-600 focus:ring-primary-500"
                />
                <span className="ml-2 text-sm text-gray-900">
                  {key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())}
                </span>
              </label>
            ))}
          </div>
        </div>
      </div>

      <div className="flex justify-between mt-8 pt-6 border-t border-gray-200">
        <button onClick={onBack} className="btn-secondary">
          Back to Timeline
        </button>
        <button 
          onClick={generateStudyPlan}
          disabled={selectedCourses.length === 0}
          className={`btn-primary ${selectedCourses.length === 0 ? 'opacity-50 cursor-not-allowed' : ''}`}
        >
          Generate My Study Plan
        </button>
      </div>
    </motion.div>
  )
}
