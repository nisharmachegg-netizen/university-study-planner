'use client'

import { useState, useEffect } from 'react'
import { MicrophoneIcon, StopIcon } from '@heroicons/react/24/outline'
import { motion } from 'framer-motion'

interface VoiceGoalInputProps {
  onGoalAdded: (goal: any) => void
}

export default function VoiceGoalInput({ onGoalAdded }: VoiceGoalInputProps) {
  const [isListening, setIsListening] = useState(false)
  const [transcript, setTranscript] = useState('')
  const [isProcessing, setIsProcessing] = useState(false)
  const [recognition, setRecognition] = useState<any>(null)

  useEffect(() => {
    if (typeof window !== 'undefined' && 'webkitSpeechRecognition' in window) {
      const SpeechRecognition = (window as any).webkitSpeechRecognition
      const recognition = new SpeechRecognition()
      
      recognition.continuous = false
      recognition.interimResults = true
      recognition.lang = 'en-US'

      recognition.onstart = () => {
        setIsListening(true)
      }

      recognition.onresult = (event: any) => {
        const current = event.resultIndex
        const transcript = event.results[current][0].transcript
        setTranscript(transcript)
      }

      recognition.onend = () => {
        setIsListening(false)
        if (transcript.trim()) {
          processVoiceInput(transcript)
        }
      }

      recognition.onerror = (event: any) => {
        console.error('Speech recognition error:', event.error)
        setIsListening(false)
      }

      setRecognition(recognition)
    }
  }, [transcript])

  const startListening = () => {
    if (recognition) {
      setTranscript('')
      recognition.start()
    }
  }

  const stopListening = () => {
    if (recognition) {
      recognition.stop()
    }
  }

  const processVoiceInput = async (text: string) => {
    setIsProcessing(true)
    
    // Simulate AI processing to extract goal information
    await new Promise(resolve => setTimeout(resolve, 1500))
    
    // Parse the voice input to extract goal details
    const goal = parseVoiceToGoal(text)
    
    setIsProcessing(false)
    setTranscript('')
    onGoalAdded(goal)
  }

  const parseVoiceToGoal = (text: string): any => {
    // Simple parsing logic - in a real app, this would use NLP/AI
    const lowerText = text.toLowerCase()
    
    let course = ''
    let goalType = 'study'
    let description = text
    
    // Extract course mentions
    const coursePatterns = [
      /(?:in|for|my)\s+([\w\s]+?)(?:\s+(?:class|course|exam|test))/i,
      /(math|science|english|history|biology|chemistry|physics|calculus|algebra|psychology|sociology|economics|computer science|programming|statistics)/i
    ]
    
    for (const pattern of coursePatterns) {
      const match = text.match(pattern)
      if (match) {
        course = match[1] || match[0]
        break
      }
    }
    
    // Determine goal type
    if (lowerText.includes('exam') || lowerText.includes('test')) {
      goalType = 'exam'
    } else if (lowerText.includes('assignment') || lowerText.includes('homework')) {
      goalType = 'assignment'
    } else if (lowerText.includes('grade') || lowerText.includes('gpa')) {
      goalType = 'grade'
    }
    
    // Generate title
    let title = 'Custom Study Goal'
    if (goalType === 'exam') {
      title = `Prepare for ${course} exam`
    } else if (goalType === 'assignment') {
      title = `Complete ${course} assignments`
    } else if (goalType === 'grade') {
      title = `Improve ${course} grade`
    }
    
    return {
      title: title,
      description: description,
      course: course || 'General',
      type: goalType,
      source: 'voice',
      priority: 'medium'
    }
  }

  return (
    <div className="bg-gradient-to-br from-primary-50 to-blue-50 p-6 rounded-xl border border-primary-200">
      <div className="text-center">
        <h4 className="text-lg font-semibold text-gray-900 mb-2">Voice Input</h4>
        <p className="text-sm text-gray-600 mb-6">
          Speak your academic goals naturally. For example: "I want to ace my calculus midterm in 3 weeks"
        </p>
        
        <div className="flex flex-col items-center space-y-4">
          <motion.button
            onClick={isListening ? stopListening : startListening}
            disabled={isProcessing}
            className={`relative w-20 h-20 rounded-full flex items-center justify-center transition-all duration-300 ${
              isListening 
                ? 'bg-red-500 hover:bg-red-600 recording-pulse' 
                : 'bg-primary-600 hover:bg-primary-700'
            } ${isProcessing ? 'opacity-50 cursor-not-allowed' : ''}`}
            whileTap={{ scale: 0.95 }}
          >
            {isProcessing ? (
              <div className="w-6 h-6 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
            ) : isListening ? (
              <StopIcon className="h-8 w-8 text-white" />
            ) : (
              <MicrophoneIcon className="h-8 w-8 text-white" />
            )}
          </motion.button>
          
          <div className="text-center min-h-[60px] flex items-center">
            {isProcessing ? (
              <p className="text-sm text-primary-600 font-medium">Processing your goal...</p>
            ) : isListening ? (
              <div>
                <p className="text-sm text-red-600 font-medium mb-1">Listening...</p>
                {transcript && (
                  <p className="text-xs text-gray-600 italic">"{transcript}"</p>
                )}
              </div>
            ) : (
              <p className="text-sm text-gray-500">
                {recognition ? 'Click the microphone to start speaking' : 'Voice input not supported in this browser'}
              </p>
            )}
          </div>
        </div>
        
        <div className="mt-4 p-3 bg-white rounded-lg border border-gray-200">
          <p className="text-xs text-gray-500 mb-2">Example phrases:</p>
          <div className="text-xs text-gray-600 space-y-1">
            <p>"I need to improve my chemistry grade this semester"</p>
            <p>"Help me prepare for my psychology final exam"</p>
            <p>"I want to finish my computer science project"</p>
          </div>
        </div>
      </div>
    </div>
  )
}
