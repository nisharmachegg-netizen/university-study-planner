'use client'

import { useState } from 'react'
import { CheckCircleIcon, PlusIcon } from '@heroicons/react/24/outline'
import { motion } from 'framer-motion'

interface GoalSelectorProps {
  onGoalSelected: (goal: any) => void
}

const predefinedGoals = [
  {
    id: 1,
    title: 'Improve GPA',
    description: 'Raise your overall GPA by focusing on weak subjects',
    category: 'Academic Performance',
    difficulty: 'Medium',
    estimatedWeeks: 8,
    icon: '📈'
  },
  {
    id: 2,
    title: 'Prepare for Midterm Exams',
    description: 'Create a comprehensive study plan for upcoming midterms',
    category: 'Exam Preparation',
    difficulty: 'High',
    estimatedWeeks: 4,
    icon: '📚'
  },
  {
    id: 3,
    title: 'Complete Research Paper',
    description: 'Plan and execute a high-quality research project',
    category: 'Assignment',
    difficulty: 'High',
    estimatedWeeks: 6,
    icon: '📝'
  },
  {
    id: 4,
    title: 'Master Programming Concepts',
    description: 'Improve coding skills and understand key programming principles',
    category: 'Skill Development',
    difficulty: 'Medium',
    estimatedWeeks: 12,
    icon: '💻'
  },
  {
    id: 5,
    title: 'Prepare for Finals',
    description: 'Comprehensive final exam preparation across all courses',
    category: 'Exam Preparation',
    difficulty: 'High',
    estimatedWeeks: 6,
    icon: '🎯'
  },
  {
    id: 6,
    title: 'Improve Study Habits',
    description: 'Develop better time management and study techniques',
    category: 'Study Skills',
    difficulty: 'Easy',
    estimatedWeeks: 4,
    icon: '⏰'
  },
  {
    id: 7,
    title: 'Language Learning',
    description: 'Master a foreign language for academic requirements',
    category: 'Skill Development',
    difficulty: 'Medium',
    estimatedWeeks: 16,
    icon: '🌍'
  },
  {
    id: 8,
    title: 'Lab Skills Improvement',
    description: 'Enhance practical laboratory skills and techniques',
    category: 'Practical Skills',
    difficulty: 'Medium',
    estimatedWeeks: 8,
    icon: '🔬'
  }
]

const categories = ['All', 'Academic Performance', 'Exam Preparation', 'Assignment', 'Skill Development', 'Study Skills', 'Practical Skills']

export default function GoalSelector({ onGoalSelected }: GoalSelectorProps) {
  const [selectedCategory, setSelectedCategory] = useState('All')
  const [selectedGoals, setSelectedGoals] = useState<number[]>([])
  const [customGoal, setCustomGoal] = useState({ title: '', description: '', course: '' })
  const [showCustomForm, setShowCustomForm] = useState(false)

  const filteredGoals = selectedCategory === 'All' 
    ? predefinedGoals 
    : predefinedGoals.filter(goal => goal.category === selectedCategory)

  const handleGoalSelect = (goal: any) => {
    if (selectedGoals.includes(goal.id)) {
      setSelectedGoals(selectedGoals.filter(id => id !== goal.id))
    } else {
      setSelectedGoals([...selectedGoals, goal.id])
      onGoalSelected({
        ...goal,
        source: 'predefined',
        priority: goal.difficulty === 'High' ? 'high' : goal.difficulty === 'Medium' ? 'medium' : 'low'
      })
    }
  }

  const handleCustomGoalSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (customGoal.title && customGoal.description) {
      onGoalSelected({
        title: customGoal.title,
        description: customGoal.description,
        course: customGoal.course || 'General',
        category: 'Custom',
        source: 'manual',
        priority: 'medium',
        icon: '✨'
      })
      setCustomGoal({ title: '', description: '', course: '' })
      setShowCustomForm(false)
    }
  }

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'Easy': return 'bg-green-100 text-green-800'
      case 'Medium': return 'bg-yellow-100 text-yellow-800'
      case 'High': return 'bg-red-100 text-red-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  return (
    <div className="bg-gradient-to-br from-secondary-50 to-cyan-50 p-6 rounded-xl border border-secondary-200">
      <div className="mb-6">
        <h4 className="text-lg font-semibold text-gray-900 mb-2">Choose from Common Goals</h4>
        <p className="text-sm text-gray-600">
          Select from our curated list of academic goals or create your own
        </p>
      </div>

      {/* Category Filter */}
      <div className="mb-6">
        <div className="flex flex-wrap gap-2">
          {categories.map(category => (
            <button
              key={category}
              onClick={() => setSelectedCategory(category)}
              className={`px-3 py-1 rounded-full text-sm font-medium transition-colors ${
                selectedCategory === category
                  ? 'bg-secondary-600 text-white'
                  : 'bg-white text-gray-600 hover:bg-gray-50 border border-gray-300'
              }`}
            >
              {category}
            </button>
          ))}
        </div>
      </div>

      {/* Goal Cards */}
      <div className="space-y-3 max-h-80 overflow-y-auto mb-4">
        {filteredGoals.map(goal => {
          const isSelected = selectedGoals.includes(goal.id)
          return (
            <motion.div
              key={goal.id}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => handleGoalSelect(goal)}
              className={`p-4 rounded-lg border cursor-pointer transition-all ${
                isSelected 
                  ? 'border-secondary-500 bg-secondary-50 shadow-md' 
                  : 'border-gray-200 bg-white hover:border-gray-300 hover:shadow-sm'
              }`}
            >
              <div className="flex items-start justify-between">
                <div className="flex items-start space-x-3 flex-1">
                  <span className="text-2xl">{goal.icon}</span>
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-1">
                      <h5 className="font-medium text-gray-900">{goal.title}</h5>
                      {isSelected && <CheckCircleIcon className="h-5 w-5 text-secondary-600" />}
                    </div>
                    <p className="text-sm text-gray-600 mb-2">{goal.description}</p>
                    <div className="flex items-center space-x-2">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${getDifficultyColor(goal.difficulty)}`}>
                        {goal.difficulty}
                      </span>
                      <span className="text-xs text-gray-500">
                        ~{goal.estimatedWeeks} weeks
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          )
        })}
      </div>

      {/* Custom Goal Section */}
      <div className="border-t border-gray-200 pt-4">
        {!showCustomForm ? (
          <button
            onClick={() => setShowCustomForm(true)}
            className="w-full flex items-center justify-center space-x-2 p-3 border-2 border-dashed border-gray-300 rounded-lg text-gray-600 hover:border-gray-400 hover:text-gray-700 transition-colors"
          >
            <PlusIcon className="h-5 w-5" />
            <span>Create Custom Goal</span>
          </button>
        ) : (
          <form onSubmit={handleCustomGoalSubmit} className="space-y-3">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Goal Title*
              </label>
              <input
                type="text"
                value={customGoal.title}
                onChange={(e) => setCustomGoal({ ...customGoal, title: e.target.value })}
                placeholder="e.g., Master Organic Chemistry"
                className="input-field"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Description*
              </label>
              <textarea
                value={customGoal.description}
                onChange={(e) => setCustomGoal({ ...customGoal, description: e.target.value })}
                placeholder="Describe what you want to achieve..."
                rows={2}
                className="input-field"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Course (Optional)
              </label>
              <input
                type="text"
                value={customGoal.course}
                onChange={(e) => setCustomGoal({ ...customGoal, course: e.target.value })}
                placeholder="e.g., CHEM 2020"
                className="input-field"
              />
            </div>
            <div className="flex space-x-2">
              <button type="submit" className="btn-primary flex-1">
                Add Goal
              </button>
              <button 
                type="button" 
                onClick={() => setShowCustomForm(false)}
                className="btn-secondary"
              >
                Cancel
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  )
}
